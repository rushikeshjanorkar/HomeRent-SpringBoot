package com.HomeRent.rentApplication.room;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
public class Room {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int roomNo;
    private String roomUserName;
    private String roomAddress;

    @Lob
    @Column(name = "panCard", columnDefinition = "MEDIUMBLOB")
    private byte[] panCard;

    @Lob
    @Column(name = "aadharCardFile", columnDefinition = "MEDIUMBLOB")
    private byte[] aadharCardFile;

    private long mobileNo;

    @Column(unique = true, nullable = false)
    private String email;

    @Column(nullable = false)
    private String password; // Hashed password will be stored
}
