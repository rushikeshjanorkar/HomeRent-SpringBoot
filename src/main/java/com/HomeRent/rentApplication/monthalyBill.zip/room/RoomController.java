package com.HomeRent.rentApplication.room;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/rooms")
public class RoomController {

    @Autowired
    private RoomService authService;

    @PostMapping("/register")
    public ResponseEntity<Room> register(@RequestBody Room room) {
        Room savedRoom = authService.registerUser(room);
        return ResponseEntity.ok(savedRoom);
    }

    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestParam String email, @RequestParam String password) {
        Room room = authService.login(email, password);
        if (room != null) {
            return ResponseEntity.ok("Login successful!");
        } else {
            return ResponseEntity.status(401).body("Invalid email or password");
        }
    }

}
