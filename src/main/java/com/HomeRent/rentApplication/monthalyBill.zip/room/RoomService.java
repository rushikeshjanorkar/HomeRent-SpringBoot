package com.HomeRent.rentApplication.room;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class RoomService {

    @Autowired
    private RoomRepository roomRepository;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    public Room registerUser(Room room) {
        // Hash the password before saving
        room.setPassword(passwordEncoder.encode(room.getPassword()));
        return roomRepository.save(room);
    }

    public Room login(String email, String password) {
        Room room = roomRepository.findByEmail(email);
        if (room != null && passwordEncoder.matches(password, room.getPassword())) {
            return room; // Login successful
        }
        return null; // Login failed
    }


}
