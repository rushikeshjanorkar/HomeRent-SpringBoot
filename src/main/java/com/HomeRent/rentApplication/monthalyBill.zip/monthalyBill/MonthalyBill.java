package com.HomeRent.rentApplication.monthalyBill;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;

import java.util.Date;

@Entity
@Data
public class MonthalyBill {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
   private int id;

    private  int roomId;

    private  Date billDate;

    private  long previousReading;

    private  long currentReading;

    private  long totalReading;

    private long totalBill;






}
